The original template files are located in TheMAG base theme directory: themes/themag/templates/.
If you plan to use future theme updates, you shouldn't modify those files.
Copy the file you wish to change and place it here, in this directory.
Make the needed changes and clear the Drupal cache.
In this way, the theme updates won't override your changes.

