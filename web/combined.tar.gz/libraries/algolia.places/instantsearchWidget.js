"use strict";

// we need to export using commonjs for ease of usage in all
// JavaScript environments
// We therefore need to import in commonjs too. see:
// https://github.com/webpack/webpack/issues/4039

/* eslint-disable import/no-commonjs */
var widget = require('./src/instantsearch/widget');

module.exports = widget["default"];
/* eslint-enable import/no-commonjs */
