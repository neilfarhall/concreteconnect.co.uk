var input = document.querySelector("#phone");
window.intlTelInput(input, {
  utilsScript: "../../build/js/utils.js?1585994360633" // just for formatting/placeholders etc
});
